
package main;


public class Asztal {
    String szin;
    int magassag;
    double szelesseg;
    void velemeny(){
        System.out.println("Kiváló");
    }
}
