
package main;

import java.util.Random;


public class Jatek {
    
    static final Random random = new Random();
    
    void start(){
        System.out.println("Gondoltam egy számra 0 és 9 között...");
        int randomsz = random.nextInt(10);
        System.out.printf("A gondolt szám: %d\n",randomsz);
    }
    
    
}
